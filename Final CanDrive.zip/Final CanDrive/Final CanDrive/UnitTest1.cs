﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Final_CanDrive
{
    [TestClass]
    public class UnitTest1
    {
        public bool CanDrive(int age)
        {

            const int drivingAge = 16;
            return age >= drivingAge;

        }

        [TestMethod]
        public void TestCaseMinVal()
        {
            Assert.AreEqual(false, CanDrive(int.MinValue));
        }

        [TestMethod]
        public void TestCaseMinValPlus()
        {
            Assert.AreEqual(false, CanDrive(int.MinValue + 1));
        }

        [TestMethod]
        public void TestCaseMinusOne()
        {
            Assert.AreEqual(false, CanDrive(-1));
        }

        [TestMethod]
        public void TestCaseZero()
        {
            Assert.AreEqual(false, CanDrive(0));
        }

        [TestMethod]
        public void TestCaseAge15()
        {
            Assert.AreEqual(false, CanDrive(15));
        }

        [TestMethod]
        public void TestCaseAge16()
        {
            Assert.AreEqual(true, CanDrive(16));
        }

        [TestMethod]
        public void TestCaseAge17()
        {
            Assert.AreEqual(true, CanDrive(17));
        }

        [TestMethod]
        public void TestCaseMaxValMinusOne()
        {
            Assert.AreEqual(true, CanDrive(int.MaxValue - 1));
        }

        [TestMethod]
        public void TestCaseMaxVal()
        {
            Assert.AreEqual(true, CanDrive(int.MaxValue));
        }
    }
}
